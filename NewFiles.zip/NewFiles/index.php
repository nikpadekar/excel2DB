<?php
require_once __DIR__ . "/mySQLConn.php";
?>
<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>css grid full screen -2-1</title>
  <link rel="stylesheet" href="./style.css">
  <script src="https://code.jquery.com/jquery-1.8.3.min.js"></script>
</head>

<body>

  <header id="pageHeader"><h2>Excel To mySQL Converter</h2></header>
<article id="mainArticle">
<form action="upload.php" method="post" enctype="multipart/form-data">
<h3 style=" background: #99ad002b; text-align: center;"> Upload File </h3>
<div style="display:inline-flex;width: -webkit-fill-available;height: 19.95rem;">
<div class="split left">
  <div class="centered">
  <input type="file" name="fileToUpload" id="fileToUpload" name="fileToUpload" capture style="display:none"/>
	<img src="https://cdn1.iconfinder.com/data/icons/file-formats-flat-colorful-round-corner/614/1732_-_XLS-512.png" id="upfile1" style="cursor:pointer" />
	<h3>SELECT FILE</h3>
  </div>
</div>

<div class="split right">
  <div class="centered">
      <input type="submit" id="file2" name="submit" capture style="display:none"/>
	<img src="https://cdn1.iconfinder.com/data/icons/metro-ui-dock-icon-set--icons-by-dakirby/512/MS_Office_Upload_Center.png" id="upfile2" style="cursor:pointer" />
	<h3>UPLOAD FILE</h3>
  </div>
</div>
</div>
</form>
</article>
<nav id="mainNav">
<h3>Project Info </h3>
<p>all project Info Goes and for new Line use '</br>'
check html File for it</p>
  </nav>
<div id="siteAds">
<h3>Sample File</h3>
<p>Below Sample xls File as well As Image Provided</p>

<h3>Download image</h3>
<span class="showonhover1">Download</span>
<input id="selectfilePNG" onclick="window.open('template.png')" style="display: none;" />
</br>
<h3>Download Xls</h3>
<span class="showonhover2">Download</span>
<input id="selectfileXLS" onclick="window.open('student.xlsx')" style="display: none;" />
</div>
<footer id="pageFooter" style="padding: 0px 1.2em;">
<table style="width: -webkit-fill-available;margin-top: 0.4rem;">
<tbody>
<tr><td style="width: 40%;padding: 0px;"><h5>MCS - 044 PROJECT<br> UNDERTAKEN BY</h5></td>
<td><table style="margin-top: -0.15rem;">
<tr><td><h5>1. HARMAN CHHURA</h5></td></tr>
<tr><td><h5>2. SEEMA SHRIKANT KADAM</h5></td></tr>
<tr><td><h5>3. HASHMI MOHAMMED ASIF</h5></td></tr>
</table></td>
</tr>
</tbody>
</table>
</footer>
  
  <script>
  $("#upfile1").click(function () {
    $("#fileToUpload").trigger('click');
});
  $("#upfile2").click(function () {
    $("#file2").trigger('click');
});
        $(".showonhover1").click(function(){
			$("#selectfilePNG").trigger('click');
		});
		        $(".showonhover2").click(function(){
			$("#selectfileXLS").trigger('click');
		});
  </script>

</body>

</html>
