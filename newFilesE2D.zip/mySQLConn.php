<?php
$servername = "localhost";
$username = "root";
$password = "";

// Creating connection
$conn = new mysqli($servername, $username, $password);

?>